"""
Pythpn Football Game
Description: Made By Joshua H
"""

import pygame, pygame.freetype, random, math
pygame.init()

def draw_field(window, first_down_line):
    window.fill((0, 128, 0))
    pygame.draw.rect(window, (0, 0, 128), pygame.Rect(0, 0, 200, 1000))
    pygame.draw.rect(window, (128, 0, 0), pygame.Rect(2200, 0, 200, 1000))
    #for i in range(200, 2201, 20): hashes
        #pygame.draw.line(window, (255, 255, 255), (i, 320), (i, 340), 5)
        #pygame.draw.line(window, (255, 255, 255), (i, 660), (i, 680), 5)
    for i in range(200, 2201, 100):
        pygame.draw.line(window, (255, 255, 255), (i, 0), (i, 1000), 5)
    pygame.draw.line(window, (255, 255, 0), (first_down_line, 0), (first_down_line, 1000), 5)
    
window = pygame.display.set_mode((2400, 1200))
c = pygame.time.Clock()

score_text = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 300)
score_text.fgcolor = (255, 255, 255)
score_text_shadow = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 300)

blue_score = 0
red_score = 0
scoreboard_text = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 200)
scoreboard_text.fgcolor = (255, 255, 255)

score_display_text = ""

down_text = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 100)
down_text.fgcolor = (255, 255, 255)
down_display_text = ""

blue_enzone = pygame.Rect(0, 0, 200, 1000)
red_enzone = pygame.Rect(2200, 0, 200, 1000)

ball = pygame.Rect(460, 500, 30, 15)
blue_qb = pygame.Rect(460, 500, 40, 40)
blue_wr1 = pygame.Rect(460, 600, 40, 40)
red_dl1 = pygame.Rect(560, 600, 40, 40)

players = [blue_qb, blue_wr1, red_dl1]

random_defense_move = ""
defense_moves = ["TOUCHDOWN"] * 20 + ["FIELD GOAL"] * 20 + ["SAFTEY"] * 5 + ["PUNT"] * 30 + ["INTERCEPTION"] * 10 + ["FUMBLE"] * 5 + ["TURNOVER"] * 10
downs = 1
first_down_line = 700
wr_speed = 5
pwp = blue_qb # player with possession
ball_height = 100
ball_height_change = 1
scored_timer = 3000
line_of_scrimmage = 500
kick_distance = 0
incomplete = False
add_points = True
punt = False
kick = False
down = False
hiked = False
scored = False
caught = False
bullet = False
lob = False
drawing = True
while drawing:
    draw_field(window, first_down_line)
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drawing = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q and not bullet and not lob:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                bullet = True
                ball_height = 0
            if event.key == pygame.K_e and not bullet and not lob:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                lob = True
                ball_height = 0
            # Pausing for screenshots
            if event.key == pygame.K_RETURN:
                pygame.time.wait(10000)
    
    if (blue_wr1.colliderect(red_enzone) and pwp == blue_wr1) or (blue_qb.colliderect(red_enzone) and pwp == blue_qb):
        blue_score += 7
        scored = True
        down = True
        score_display_text = "TOUCHDOWN"
        
    if red_dl1.colliderect(blue_enzone) and pwp == red_dl1:
        red_score += 7
        down = True
        add_points = False
        score_display_text = "TOUCHDOWN"
    
    if blue_wr1.colliderect(red_dl1) and random.randint(25, 50) == 42 and pwp == blue_wr1:
        down = True
    if (blue_wr1.colliderect(red_dl1) or blue_qb.colliderect(red_dl1)) and random.randint(25, 50) == 42 and pwp == red_dl1:
        add_points = True
        down = True
        scored = True
    
    if blue_qb.y < 0 or blue_wr1.y < 0 or blue_qb.y + blue_qb.height > 1000 or blue_wr1.y + blue_wr1.height > 1000:
        down = True
        
    if down:
        if not incomplete:
            line_of_scrimmage = blue_wr1.x
        lob = False
        bullet = False
        hiked = False
        caught = False
        downs += 1
        if downs > 4 or scored:
            downs = 1
            random_defense_move = random.choice(defense_moves)
            if random_defense_move == "PUNT" and line_of_scrimmage < 1000:
                if random.choice([1, 1, 1, 1, 2]) == 2:
                    score_display_text = "MISSED FG"
                    random_defense_move = ""
                else:
                    random_defense_move = "FIELD GOAL"
            if random_defense_move == "TOUCHDOWN":
                if add_points:
                    red_score += 7
                line_of_scrimmage = random.choice([500, 600, 700, 800])
                score_display_text = random_defense_move
            elif random_defense_move == "FIELD GOAL":
                if add_points:
                    red_score += 3
                line_of_scrimmage = random.choice([500, 600, 700, 800])
                score_display_text = random_defense_move
            elif random_defense_move == "SAFTEY":
                if add_points:
                    blue_score += 2
                line_of_scrimmage = random.choice([500, 600, 700, 800])
                score_display_text = random_defense_move
            elif random_defense_move == "PUNT":
                line_of_scrimmage = random.choice([500, 600, 700, 800])
                score_display_text = random_defense_move
            elif random_defense_move == "INTERCEPTION":
                line_of_scrimmage = red_dl1.x
                score_display_text = random_defense_move
            elif random_defense_move == "FUMBLE":
                line_of_scrimmage = red_dl1.x
                score_display_text = random_defense_move
            elif random_defense_move == "TURNOVER":
                line_of_scrimmage = red_dl1.x
                score_display_text = random_defense_move
            first_down_line = line_of_scrimmage + 200
        pwp = blue_qb
        blue_qb.x = line_of_scrimmage - 40
        blue_qb.y = 500
        blue_wr1.x = line_of_scrimmage - 40
        blue_wr1.y = 600
        red_dl1.x = line_of_scrimmage + 60
        red_dl1.y = 600
        down = False
        if ball.x >= first_down_line:
            first_down_line = ball.x + 200
            downs = 1
    
    """if lob or bullet:
        x_distance = abs(blue_qb.x - mouse_x)
        y_distance = abs(blue_qb.y - mouse_y)
        x_dist_squared = x_distance ** 2
        y_dist_squared = y_distance ** 2
        distance = int(math.sqrt((x_dist_squared + y_dist_squared)))
        radius = distance // 2
        ball_height += 1
        if ball_height >= radius:
            ball_height_change *= -1"""
    
    for player in players:
        if ball.colliderect(player):
            if player != players[0]:
                if not caught:
                    pwp = player
                caught = True
    
    if lob or bullet:
        if ball.x != mouse_x or ball.y != mouse_y:
            if lob:
                if abs(ball.x - mouse_x) <= 5:
                    ball.x = mouse_x
                if abs(ball.y - mouse_y) <= 5:
                    ball.y = mouse_y
                if abs(ball.x - mouse_x) >= 5 or abs(ball.y - mouse_y) >= 5:
                    angle = math.atan2(mouse_y - ball.y, mouse_x - ball.x)
                    mvx = math.cos(angle) * 15
                    mvy = math.sin(angle) * 15
                    ball.x += int(mvx)
                    ball.y += int(mvy)
                    
            if bullet:
                if abs(ball.x - mouse_x) <= 10:
                    ball.x = mouse_x
                if abs(ball.y - mouse_y) <= 10:
                    ball.y = mouse_y
                if abs(ball.x - mouse_x) >= 10 or abs(ball.y - mouse_y) >= 10:
                    angle = math.atan2(mouse_y - ball.y, mouse_x - ball.x)
                    mvx = math.cos(angle) * 30
                    mvy = math.sin(angle) * 30
                    ball.x += int(mvx)
                    ball.y += int(mvy)
        else:
            incomplete = True
            lob = False
            bullet = False
    
    if incomplete:
        down = True
    
    if keys[pygame.K_w]:
        blue_qb.y -= 5
    if keys[pygame.K_s]:
        blue_qb.y += 5
    if keys[pygame.K_a]:
        blue_qb.x -= 5
    if keys[pygame.K_d]:
        blue_qb.x += 5
    
    if keys[pygame.K_UP]:
        blue_wr1.y -= wr_speed
    if keys[pygame.K_DOWN]:
        blue_wr1.y += wr_speed
    if keys[pygame.K_LEFT]:
        blue_wr1.x -= wr_speed
    if keys[pygame.K_RIGHT]:
        blue_wr1.x += wr_speed
    
    if pwp == blue_wr1:
        wr_speed = 4
    else:
        wr_speed = 5
    
    if pwp != red_dl1:
        if abs(red_dl1.x - blue_wr1.x) > 20 or abs(red_dl1.y - blue_wr1.y) > 20:
            red_dl1_angle = math.atan2(blue_wr1.y - red_dl1.y, blue_wr1.x - red_dl1.x)
            red_dl1_mvx = math.cos(red_dl1_angle) * 6.5
            red_dl1_mvy = math.sin(red_dl1_angle) * 6.5
            red_dl1.x += int(red_dl1_mvx)
            red_dl1.y += int(red_dl1_mvy)
    else:
        dl1_angle = math.atan2(460 - red_dl1.y, 100 - red_dl1.x)
        dl1_mvx = math.cos(dl1_angle) * 4.5
        dl1_mvy = math.sin(dl1_angle) * 4.5
        red_dl1.x += int(dl1_mvx)
        red_dl1.y += int(dl1_mvy)
        
    if (not lob and not bullet) and pwp == blue_qb:
        ball.x = blue_qb.x + 10
        ball.y = blue_qb.y + 5
    if caught:
        ball.x = pwp.x + 10
        ball.y = pwp.y + 5

    if (bullet or lob) and not caught:
        pygame.draw.circle(window, (255, 255, 0), (mouse_x, mouse_y), 5)
    
    if downs == 1:
        down_display_text = "1st and 10"
    elif downs == 2:
        down_display_text = "2nd and " + str((first_down_line - line_of_scrimmage)//20)
    elif downs == 3:
        down_display_text = "3rd and " + str((first_down_line - line_of_scrimmage)//20)
    elif downs == 4:
        down_display_text = "4th and " + str((first_down_line - line_of_scrimmage)//20)
    
    pygame.draw.ellipse(window, (0, 0, 200), blue_qb)
    pygame.draw.ellipse(window, (0, 0, 200), blue_wr1)
    pygame.draw.ellipse(window, (200, 0, 0), red_dl1)
    pygame.draw.ellipse(window, (102, 51, 0), ball)
    
    pygame.draw.rect(window, (0, 0, 0), pygame.Rect(0, 1000, 2400, 200))
    scoreboard_text.render_to(window, (75, 1025), "Blue: " + str(blue_score))
    scoreboard_text.render_to(window, (1000, 1025), "Red: " + str(red_score))
    down_text.render_to(window, (1800, 1065), down_display_text)
    
    c.tick(30)
    pygame.display.flip()
    
    while not hiked:
        draw_field(window, first_down_line)
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    hiked = True
                    lob = False
                    bullet = False
                    caught = False
                    scored = False
                    add_points = True
                    incomplete = False
                    scored_timer = 3000
                    pwp = blue_qb
                    score_display_text = ""
                if event.key == pygame.K_p:
                    punt = True
                if event.key == pygame.K_k:
                    kick = True
        
        score_text_rect = score_text.get_rect(score_display_text)
        
        if incomplete:
            score_display_text = "INCOMPLETE"
        
        if downs == 1:
            down_display_text = "1st and 10"
        elif downs == 2:
            down_display_text = "2nd and " + str((first_down_line - line_of_scrimmage)//20)
        elif downs == 3:
            down_display_text = "3rd and " + str((first_down_line - line_of_scrimmage)//20)
        elif downs == 4:
            down_display_text = "4th and " + str((first_down_line - line_of_scrimmage)//20)
        
        pygame.draw.ellipse(window, (0, 0, 200), blue_qb)
        pygame.draw.ellipse(window, (0, 0, 200), blue_wr1)
        pygame.draw.ellipse(window, (200, 0, 0), red_dl1)
        pygame.draw.ellipse(window, (102, 51, 0), ball)
        
        pygame.draw.rect(window, (0, 0, 0), pygame.Rect(0, 1000, 2400, 200))
        scoreboard_text.render_to(window, (75, 1025), "Blue: " + str(blue_score))
        scoreboard_text.render_to(window, (1000, 1025), "Red: " + str(red_score))
        down_text.render_to(window, (1800, 1065), down_display_text)
        
        scored_timer -= c.get_time()
        if scored_timer >= 0 and (scored or incomplete):
            score_text_shadow.render_to(window, (2400 * 0.5 - score_text_rect.width * 0.5, 375), score_display_text)
            score_text.render_to(window, ((2400 * 0.5 - score_text_rect.width * 0.5) + 25, 400), score_display_text)
        
        if scored:
            downs = 1
        
        c.tick(30)
        pygame.display.flip()
      